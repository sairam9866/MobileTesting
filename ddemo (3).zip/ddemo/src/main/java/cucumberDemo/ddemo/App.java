package cucumberDemo.ddemo;

//import java.net.MalformedURLException;
//import java.net.URL;
//import java.util.concurrent.TimeUnit;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.Dimension;
//import org.openqa.selenium.remote.DesiredCapabilities;
//import org.testng.annotations.Test;
//
//import constantStrings.Strings;
//import io.appium.java_client.android.AndroidDriver;

/**
 * Hello world!
 *
 */
public class App 
{
//	public DesiredCapabilities caps = new DesiredCapabilities();
//	public static AndroidDriver driver;
//	public static Dimension size;
//
//	@Test
//	public void setCapabilities() throws MalformedURLException {
//		caps.setCapability("deviceName", Strings.device_name);
//		caps.setCapability("udid","emulator-5554"); 
//		caps.setCapability("platformName", "Android");
//		caps.setCapability("platformVersion", "8.0.0");
//		caps.setCapability("unicodeKeyboard", true);
//		caps.setCapability("resetKeyboard", true);
//		caps.setCapability("appPackage", Strings.app_package);
//		caps.setCapability("appActivity", Strings.app_activity);
//		caps.setCapability("newCommandTimeout", 10000);
//		caps.setCapability("platformName", "Android");
//		driver =new AndroidDriver( new URL("http://127.0.0.1:4723/wd/hub"),caps);
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MINUTES);
//		size = driver.manage().window().getSize();
//		
//		driver.findElement(By.xpath("//[@id='countrySpinner']/android.widget.TextView")).click();
//		
//	}
  
}
