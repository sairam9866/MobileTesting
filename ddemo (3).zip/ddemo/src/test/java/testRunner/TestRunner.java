package testRunner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.TestNGCucumberRunner;
import cucumber.api.testng.CucumberFeatureWrapper;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

//import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;

import appiumCommands.AppiumMethods;

@CucumberOptions(
		features = "src/test/resources/features",
		dryRun=false,
		glue = {"stepDefinitions"},
		tags = {"~@PUDO_Sprint_1","~@Smoke","~@Test","~@Sanity","~@Sprint9","@Sprint17","~@Sprint11","~@Reg"},
		plugin = ("json:target/cucumber-reports/CucumberTestReport.json"),
		format = {
				"pretty",
				"html:target/cucumber-reports/cucumber-pretty",
				"json:target/cucumber-reports/CucumberTestReport.json",
				"rerun:target/cucumber-reports/rerun.txt",
				"junit:target/cucumber-reports/Cucumber.xml"
		})
public class TestRunner {
	private TestNGCucumberRunner testNGCucumberRunner;
	public static int num=0;
	public static int total=0;
	public static boolean firstExecution=true;
	static AppiumMethods appiumMethod=new AppiumMethods(); 
	
	@BeforeClass(alwaysRun = true)
	public void setUpClass() throws Exception {
		appiumMethod.setCapabilities();
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	}

	@Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
	public void feature(CucumberFeatureWrapper cucumberFeature) {
		testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
	}

	@DataProvider
	public Object[][] features() {
		return testNGCucumberRunner.provideFeatures();
	}

	@AfterClass(alwaysRun = true)
	public void tearDownClass() throws Exception {
		testNGCucumberRunner.finish();
	}
}