package appiumCommands;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebElement;

import constantStrings.Strings;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

@SuppressWarnings("rawtypes")
public class AppiumMethods {
	public DesiredCapabilities caps = new DesiredCapabilities();
	public static AndroidDriver driver;
	public static Dimension size;
	public void setCapabilities() throws MalformedURLException {
		caps.setCapability("deviceName", Strings.device_name);
		//caps.setCapability("udid","emulator-5554"); 
		caps.setCapability("platformName", "Android");
		//caps.setCapability("platformVersion", "9.0.0");
		caps.setCapability("unicodeKeyboard", true);
		caps.setCapability("resetKeyboard", true);
		caps.setCapability("appPackage", Strings.app_package);
		caps.setCapability("appActivity", Strings.app_activity);
		caps.setCapability("newCommandTimeout", 50000);
		//caps.setCapability("platformName", "Android");
		driver =new AndroidDriver( new URL("http://127.0.0.1:4723/wd/hub"),caps);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MINUTES);
		size = driver.manage().window().getSize();
	}
	public boolean elementIsDisplayed(String element) {
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		if(!(findElement(element))) {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.MINUTES);
			return true;
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MINUTES);
		return false;
	}

	public void clickElement(String element) {
		if ((element.contains("//")) || (element.contains("/hierarchy/"))){
			driver.findElementByXPath(element).click();
		} 
		//		else if(element.contains("resource-id"))
		//			driver.findElementByXPath(//*[contains(@name,'btn')]);-
		//driver.findElementByXPath("//android.widget.Button[@resource-id='com.fedex.pudo:id/confirm_refusal']").click();
		else{
			driver.findElementById(Strings.app_package+":id/"+element).click();
		}
	}

	public boolean findElement(String element) {
		if (element.contains("//")){
			return driver.findElementsByXPath(element).isEmpty();
		} else {
			return driver.findElementsById(Strings.app_package+":id/"+element).isEmpty();
		}
	}
	public void sendKeysToElement(String element, String value) throws InterruptedException {
		driver.findElementById(Strings.app_package+":id/"+element).clear();
		driver.findElementById(Strings.app_package+":id/"+element).sendKeys(value);

	}
	public void setTimeout(int i) {
		driver.manage().timeouts().implicitlyWait(i, TimeUnit.MINUTES);
	}

	public void clickSwitchApp() {
		driver.pressKey(new KeyEvent(AndroidKey.APP_SWITCH));
	}

	public void sleep(int seconds) throws InterruptedException {
		Thread.sleep(seconds);
	}

	public void scrollToElementByTextContains(String text) {
	    driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0))" +
	            ".scrollIntoView(new UiSelector().textContains(\"" + text + "\").instance(0));");
	}
	public void longPress(String elementName) {
		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.longPress(LongPressOptions.longPressOptions().withElement (ElementOption.element(driver.findElementByXPath(elementName)))).perform();
	}

	public String getText(String elementName) {
		return driver.findElementById(Strings.app_package+":id/"+elementName).getText();
	}

	public void swipeLeft() throws InterruptedException {
		sleep(4000);
		//		int anchor = (int) (size.width * 0.56);
		//		int startPoint = (int) (AppiumMethods.size.width * 0.8);
		//		int endPoint = (int) (AppiumMethods.size.width * 0.3);
		size = driver.manage().window().getSize();
		System.out.println(size);
		int startx = (int) (size.width * 0.65);
		int endx = (int) (size.width * 0.26);
		int starty = size.height / 3;
		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.press(PointOption.point(startx, starty)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(500))).moveTo(PointOption.point(endx, starty)).release().perform();
		//sleep(6000);
		System.out.println("start:- "+startx+"end:- "+ endx+ " anchor:- "  +starty);

	}
	public void swiptToBottom()
	{
		Dimension dim = driver.manage().window().getSize();
		int height = dim.getHeight();
		int width = dim.getWidth();
		int x = width/2;
		int top_y = (int)(height*0.73);
		int bottom_y = (int)(height*0.27);
		//System.out.println("coordinates :" + x + "  "+ top_y + " "+ bottom_y);
		TouchAction ts = new TouchAction(driver);
		ts.press(PointOption.point(x, top_y)).moveTo(PointOption.point(x, bottom_y)).release().perform();		
	}
	public void clickBack() {
		driver.pressKey(new KeyEvent(AndroidKey.BACK));
	}
	public void click_home()
	{
		clickElement("toolbar_home_icon");
		yes_confirm();
	}
	public static void scrollToElement(){
		//AndroidDriver driver, String elementName, boolean scrollDown
		/*String listID = ((RemoteWebElement) driver.findElementByAndroidUIAutomator("new UiSelector().className(\"android.webkit.WebView\")")).getId();
			String direction = null;
			if (scrollDown) {
				direction = "down";
			} else {
				direction = "up";
			}
			HashMap<String, String> scrollObject = new HashMap<String, String>();
			scrollObject.put("direction", direction);
			scrollObject.put("element", listID);
			scrollObject.put("text", elementName);
			driver.executeScript("mobile: scrollTo", scrollObject);*/

		/*	//Robot�robot�=�new�Robot();
//		Robot.keyPress(KeyEvent.VK_PAGE_DOWN);
//		Robot.keyRelease(KeyEvent.VK_PAGE_DOWN); 
		JavascriptExecutor jse = (JavascriptExecutor)driver;

		jse.executeScript("window.scrollBy(0,250)", "");
		//jse.executeScript("scroll(0, 250);");
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");*/
		MobileElement el = (MobileElement) driver
				.findElementByAndroidUIAutomator("new UiScrollable("
						+ "new UiSelector().scrollable(true)).scrollIntoView("                      
						+ "new UiSelector().textContains(\"Accept and Continue\"));");
		el.click();
	}
	public void yes_confirm() {
		clickElement("//android.widget.Button[@text='YES']");
	}	
}
