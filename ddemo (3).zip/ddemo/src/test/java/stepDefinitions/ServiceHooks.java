package stepDefinitions;

import appiumCommands.AppiumMethods;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import testRunner.TestRunner;

public class ServiceHooks {
	static AppiumMethods app= new AppiumMethods();
	@Before
	public void initializeTest(){
		// Code to setup initial configurations
	}

	@After
	public void embedScreenshot(Scenario scenario) throws InterruptedException {
		if (scenario.isFailed()) {
			try {
				/*final byte[] screenshot = ((TakesScreenshot) TestRunner.driver)
						.getScreenshotAs(OutputType.BYTES);
				scenario.embed(screenshot, "image/png");*/
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(TestRunner.num==TestRunner.total) {
			TestRunner.num=0;
			TestRunner.total=0;
		}
		app.sleep(3000);
	}
}