package stepDefinitions;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;

import appiumCommands.AppiumMethods;
import constantStrings.Strings;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import testRunner.TestRunner;

public class StepDefinitions {
	private boolean check = false;
	private boolean goToDasboard = true;
	private String[] elementArray;
	private String[] successElementArray = new String[] {};
	private boolean pack = true;
	static AppiumMethods appiumMethod = new AppiumMethods();
	@SuppressWarnings("rawtypes")
	TouchAction touchAction = new TouchAction(AppiumMethods.driver);

	// Givens
	@Given("^Hamburger Menu is open$")
	public void open_menu() {
		if (appiumMethod.elementIsDisplayed("menuRight")) {
			appiumMethod.clickElement("menuRight");
		}
	}

	// Whens
	@When("^User is logged in with username ([^\"]*) and password ([^\"]*)$")
	public void login_with_credentials(String userName, String userPassword)
			throws MalformedURLException, InterruptedException {
		appiumMethod.findElement("loginTitle");
		appiumMethod.sendKeysToElement("user_id", userName);
		appiumMethod.sendKeysToElement("password", userPassword);
		appiumMethod.clickElement("sign_in_button");
	}

	@Then("([^\"]*) should be displayed")
	public void Text_display(String element) {
		appiumMethod.elementIsDisplayed(element);
	}

	@When("User enters \"([^\"]*)\" in the Package inquiry bar")
	public void input_tracking_number(String value) throws InterruptedException {
		appiumMethod.sendKeysToElement("scan_barcode_edit", value);
		appiumMethod.clickElement("go_button");

	}

	@When("User clicks on the filter button on the map")
	public void filter_retail_points() throws InterruptedException {
		appiumMethod.sleep(2000);
		appiumMethod.clickElement("distance_set");
		appiumMethod.sleep(2000);
		appiumMethod.clickElement("distance_slider");
	}

	@When("^User is on the Dashboard$")
	public void dashboard() {
		if (appiumMethod.elementIsDisplayed("toolbar_home_icon")) {
			appiumMethod.clickElement("toolbar_home_icon");
		} else {
			return;
		}
	}

	@When("User clicks camera in the Package inquiry bar and scans ([^\"]*) barcode")
	public void click_cam(String element) throws InterruptedException {
		appiumMethod.clickElement("barcode_scanner");
		checkAndAllow();
		appiumMethod.sleep(4000);
		if (element.contains("valid"))
			appiumMethod.clickElement("go_button");

	}

	@When("User clicks on the ([^\"]*) and clicks ([^\"]*) option")
	public void tab_opener(String tabName, String option) {
		appiumMethod.clickElement("//*[@text='" + tabName + "']");
		appiumMethod.clickElement(option);
	}

	@When("User clicks on the ([^\"]*) tab")
	public void click_tabs(String tab_name) {
		appiumMethod.clickElement("//*[@text='" + tab_name + "']");
	}

	@When("^User clicks on ([^\"]*) in Hamburger Menu$")
	public void should_be_open(String elementName) throws InterruptedException {
		if (elementName.contains("Legal & Terms")) {
			TestRunner.total = 3;
		} else {
			TestRunner.total = 1;
		}
		if (TestRunner.num == 0) {
			appiumMethod.clickElement("//*[@text='" + elementName + "']");
			if (elementName.contains("Find Location")) {
				appiumMethod.sleep(6000);
				checkAndAllow();
				check = true;
			}
			TestRunner.num++;
			return;
		}
		TestRunner.num++;
	}

	@When("^User clicks on ([^\"]*) in ([^\"]*) Submenu$")
	public void should_be_open_submenu(String elementName, String subMenuName) {
		appiumMethod.clickElement("menuRight");
		appiumMethod.clickElement("//*[@text='" + subMenuName + "']");
		appiumMethod.clickElement("//*[@text='" + elementName + "']");
	}

	@When("^The User clicks on Logout$")
	public void logout() {
		appiumMethod.clickElement("menuRight");
		appiumMethod.clickElement("//*[@text='Logout']");
	}

	@When("^User clicks on the Camera button$")
	public void open_camera() throws InterruptedException {
		appiumMethod.clickElement("barcode_scanner");
		appiumMethod.sleep(1500);
		checkAndAllow();
		check = true;
	}

	@When("^User click on ([^\"]*) in ([^\"]*)$")
	public void open_camera_tab(String elementName, String tabName) throws InterruptedException {
		appiumMethod.clickElement("//*[@text='" + tabName + "']");
		appiumMethod.clickElement("//*[@text='" + elementName + "']");
		checkAndAllow();

	}

	@When("^User enters username ([^\"]*) and password ([^\"]*) on login screen$")
	public void user_on_login_page(String userName, String userPassword) throws InterruptedException {
		if (appiumMethod.elementIsDisplayed("//*[@text='Accept Packages']")) {
			logout();
			logout_confirmation();
		}
		appiumMethod.sendKeysToElement("user_id", userName);
		appiumMethod.sendKeysToElement("password", userPassword);
	}

	@When("^User clicks on the show password$")
	public void show_password() {
		appiumMethod.clickElement(Strings.EYE_ICON);

	}

	@When("^User clicks on the switch application$")
	public void switch_application() throws InterruptedException {
		appiumMethod.sleep(1500);
		appiumMethod.clickSwitchApp();
	}

	@When("^User long presses the messages$")
	public void long_press_message() {
		appiumMethod.longPress(Strings.long_press_message_XPath);
	}

	@When("^User clicks on multiple checkboxes$")
	public void multiple_checkboxes() {
		for (int i = 1; i <= 5; i += 2) {
			appiumMethod.clickElement(Strings.return_checkbox_XPath(i));
		}
	}

	@When("User clicks on ([^\"]*) option ([^\"]*)")
	public void click_element(String elementName, String position) {
		if ((elementName.contains("NO")) || (elementName.contains("YES")) || (elementName.contains("YEs"))) {
			if (elementName.contains("YEs"))
				appiumMethod.clickElement("//android.widget.Button[@text='NO']");
			else
				appiumMethod.clickElement("//android.widget.Button[@text='" + elementName + "']");
		} else if ((elementName.contains("Delete")) && (position.contains("at the bottom of the screen")))
			appiumMethod.clickElement(Strings.bottom_delete_XPath);
		else if ((elementName.contains("Delete")) && (position.contains("in the list")))
			appiumMethod.clickElement(Strings.list_delete_XPath);
		else if (position.contains("in the dropdown")) {
			click_dropdown();
			appiumMethod.clickElement("//android.widget.CheckedTextView[@text='" + elementName + "']");
		} else
			appiumMethod.clickElement("//android.widget.TextView[@text='" + elementName + "']");
	}

	@When("^User clicks on any of the locations$")
	public void click_location_marker() throws InterruptedException {
		appiumMethod.sleep(2000);
		appiumMethod.clickElement("//android.view.View[@content-desc=\"Google Map\"]/android.view.View[4]");
	}

	@When("^User clicks on the dropdown$")
	public void click_dropdown() {
		appiumMethod.clickElement("spinnerLayout");
	}

	@When("^User clicks on any shipment$")
	public void click_shipment() {
		appiumMethod.clickElement(Strings.click_shipment_XPath);
	}

	@When("^Package with tracking number \"([^\"]*)\" is added$")
	public void search_package_when(String packageID) throws InterruptedException {
		// search_package_scanned_list(packageID);
		pack = false;
		search_package(packageID);
	}

	@When("^Package with tracking number \"([^\"]*)\" is added for release$")
	public void search_package_release(String packageID) throws InterruptedException {
		pack = false;
		search_package(packageID);
	}

	@When("^Package with tracking number \"([^\"]*)\" is added in the Scanned List$")
	public void search_package_scanned_list(String packageID) throws InterruptedException {
		for (int i = 0; i < 3; i++) {
			String message = "Package with id " + packageID + " not found\n";
			Assert.assertFalse(appiumMethod.findElement("//android.widget.TextView[@text='" + packageID + "']"),
					message);
			appiumMethod.clickElement("next");
		}
	}
	@Then("^User Scans the barcodes in the ([^\"]*) and tracking numbers are added into the scanned list$")
	public void scan_multiple_barcodes(String element) throws InterruptedException
	{
		for (int i = 0; i < 6; i++) {
			appiumMethod.elementIsDisplayed("next");
			appiumMethod.clickElement("next");
		}
		appiumMethod.sleep(4000);
		appiumMethod.clickElement("done");
		if(appiumMethod.elementIsDisplayed("release_packages"))
			appiumMethod.clickElement("release_packages");
	}

	@When("^User swipes from left to right on any message$")
	public void swipe_to_delete_message() throws InterruptedException {
		appiumMethod.swipeLeft();
	}

	@And("User enters email and clicks next")
	public void input_email() throws InterruptedException {
		appiumMethod.clickElement("accept_packages");
		appiumMethod.sendKeysToElement("email", "Fedricksmith@fedex.com");
		appiumMethod.clickElement("go_home");
	}

	// Thens
	@Then("retail point markers should be shown")
	public void retail_markers() throws InterruptedException {
		appiumMethod.sleep(5000);
	}

	@Then("^([^\"]*) should be present on the screen$")
	public void should_be_present_menu(String elementName) throws InterruptedException {
		String message = "Element " + elementName + " not found\n";
		appiumMethod.setTimeout(0);
		if (elementName.contains("Package List"))
			appiumMethod.sleep(5000);
		else if (elementName.contains("Shipment details")) {
			elementArray = new String[] { "status_progress", "collection_date", "total_pieces", "total_weight",
					"current_state", "name", "address", "telephone", "home_button" };
			goToDasboard = false;
			elementArrayCheck();
		} else
			Assert.assertFalse(appiumMethod.findElement("//*[@text='" + elementName + "']"), message);
		appiumMethod.setTimeout(10);
		if (elementName.contains("Package List"))
			appiumMethod.clickElement("toolbar_home_icon");
	}

	@Then("^The correct screen should be shown$")
	public void check_screen_copy() throws InterruptedException {
		check_screen();
	}

	@Then("^All the checkboxes should disappear$")
	public void check_screen() throws InterruptedException {
		appiumMethod.sleep(500);
		if (appiumMethod.elementIsDisplayed("close_button"))
			appiumMethod.clickElement("close_button");
		else if (appiumMethod.elementIsDisplayed("toolbar_home_icon"))
			appiumMethod.clickElement("toolbar_home_icon");
	}

	@Then("^The User should be successfully logged out$")
	public void logout_confirmation() {
		appiumMethod.clickElement("//android.widget.Button[@text='LOGOUT']");
	}

	@Then("^Package with tracking number \"([^\"]*)\" should be added$")
	public void search_package(String packageID) throws InterruptedException {
		scan_barcode(packageID);
		if (pack) {
			appiumMethod.click_home();
		}
	}
	@Then("^Package with invalid tracking number \"([^\"]*)\" should be added$")
	public void scan_barcode(String packageID) throws InterruptedException {
		String message = "Package with id " + packageID + " not found\n";
		if (check) { Assert.assertFalse(appiumMethod.findElement("//android.widget.EditText[@text='" + packageID + "']"), message);
		check = false; } 
		else {
			Assert.assertFalse(appiumMethod.findElement("//android.widget.TextView[@text='" + packageID + "']"), message);
			appiumMethod.sleep(200);
			if (appiumMethod.elementIsDisplayed("done"))
				appiumMethod.clickElement("done");
		}
	}

	@Then("^Password should not be visible$")
	public void password_visibility() throws InterruptedException {
		appiumMethod.sleep(2000);
		appiumMethod.clickSwitchApp();
		appiumMethod.clickElement("sign_in_button");
	}

	@Then("^All the checkboxes should be selected$")
	public void checkboxes() throws InterruptedException {
		appiumMethod.sleep(1500);
		if (appiumMethod.elementIsDisplayed("//android.widget.TextView[@text='Reset']"))
			appiumMethod.sleep(2000);
		check_screen();
	}

	@Then("^The messages should be deleted$")
	public void deleted_mesages() throws InterruptedException {
		check_screen();
	}

	@Then("^The text on the ([^\"]*) should change from \'([^\"]*)\' to \'([^\"]*)\'$")
	public void check_changed_text(String elementType, String oldString, String newString) throws InterruptedException {
		String oldElement = "//android.widget." + elementType + "[@text='" + oldString + "']";
		String newElement = "//android.widget." + elementType + "[@text='" + newString.toUpperCase() + "']";
		String message = "Element " + oldElement + " not changed to " + newElement + "\n";
		if (!(!(appiumMethod.elementIsDisplayed(oldElement)) && (appiumMethod.elementIsDisplayed(newElement))))
			throw new AssertionError(message);
		check_screen();
	}

	@Then("^([^\"]*) should contain ([^\"]*)$")
	public void check_inventory_list(String containerName, String elements) throws InterruptedException {
		if (containerName.contains("Package list")) {
			elementArray = new String[] { "shipment_no", "recipient_name", "status", "package_location" };
		}
		if (containerName.contains("Shipment details")) {
			elementArray = new String[] { "on_board_date", "status_days", "recipient_name", "status",
					"release_package_button", "tracking_number" };
			goToDasboard = true;
		}
		elementArrayCheck();
		if (containerName.contains("Shipment details")) {
			appiumMethod.clickElement("release_package_button");
			appiumMethod.findElement("release_package");
			appiumMethod.clickElement("IDimage");
			appiumMethod.clickElement("customer_id_verified");
			appiumMethod.sleep(2000);
			appiumMethod.clickElement("accept_package");
			appiumMethod.clickElement("go_home");
		}
		if (containerName.contains("Package list")) {
			appiumMethod.clickElement("toolbar_home_icon");
		}
	}

	@Then("^([^\"]*) screen for ([^\"]*) should be shown$")
	public void show_screen(String flowType, String screenType) throws InterruptedException {
		if (flowType.contains("Accept Package")) {
			if (screenType.contains("courier")) {
				elementArray = new String[] { "accept_packages", "go_home" };

			} else if (screenType.contains("customer")) {
				elementArray = new String[] { "accept_packages", "go_home", "go_home" };
			}
		} else if (flowType.contains("Success")) {
			if (screenType.contains("Accept Packages Courier")) {
				elementArray = new String[] { "accept_packages" };
				successElementArray = new String[] { "success_message",
						Strings.accept_packages_courier_success_message };
				goToDasboard = true;
			} else if (screenType.contains("Release Customer")) {
				elementArray = new String[] { "IDimage", "customer_id_verified", "accept_package" };
				successElementArray = new String[] { "success_message",
						Strings.release_package_customer_success_message };
				goToDasboard = true;
			} else if (screenType.contains("Release Courier")) {
				elementArray = new String[] { "release_packages" };
				successElementArray = new String[] { "success_message",
						Strings.release_package_courier_success_message };
				goToDasboard = true;
			} else if (screenType.contains("Accept Packages Customer")) {
				elementArray = new String[] { "tracking_num" };
				successElementArray = new String[] { "success_message",
						Strings.accept_packages_customer_success_message };
				goToDasboard = true;
			} else if (screenType.contains("Refusal Package")) {
				elementArray = new String[] { "release_package" };
				successElementArray = new String[] { "success_message", Strings.refusal_success_msg1 };
				goToDasboard = true;
			} else if (screenType.contains("Request Package Collection")) {
				elementArray = new String[] { "success" };
				successElementArray = new String[] { "success_message", Strings.request_collection_success_msg };
				goToDasboard = true;
			}
		} else if (flowType.contains("Email")) {
			if (screenType.contains("Accept Packages Customer")) {
				elementArray = new String[] { "accept_packages" };
				successElementArray = new String[] { "email_msg", Strings.email_msg };
				goToDasboard = false;
			}
		} else if (flowType.contains("Release Package")) {
			if (screenType.contains("customer")) {
				elementArray = new String[] { "IDimage", "customer_id_verified", "accept_package", "go_home" };
			} else if (screenType.contains("Customers")) {
				elementArray = new String[] { "IDimage", "customer_id_verified", "refuse_package" };
				goToDasboard = false;
			} else if (screenType.contains("the")) {
				elementArray = new String[] { "release_package_button", "IDimage", "customer_id_verified",
				"refuse_package" };
				goToDasboard = false;
			}
		}
		elementArrayClick();
	}

	@Then("Mail validation should be done")
	public void mail_validation() throws InterruptedException {
		appiumMethod.sendKeysToElement("email", "Fedricksmith@fedex.com");
		check_screen();
	}

	@Then("^The Shipment List should be updated$")
	public void shipment_list() throws InterruptedException {
		check_screen();
	}

	@Then("^The shipment should be deleted$")
	public void shipment_is_deleted() throws InterruptedException {
		for (int i = 0; i < 2; i++) {
			appiumMethod.clickBack();
			appiumMethod.sleep(1000);
		}
	}

	private void checkAndAllow() throws InterruptedException {
		for (int c = 0; c < 2; c++) {
			if (!(appiumMethod.elementIsDisplayed("//*[@text='ALLOW']")))
				appiumMethod.sleep(1500);
			else if (appiumMethod.elementIsDisplayed("//*[@text='ALLOW']"))
				appiumMethod.clickElement("//*[@text='ALLOW']");
			continue;
		}
	}

	private void elementArrayCheck() throws InterruptedException {
		List<String> errors = new ArrayList<String>();
		for (String element : elementArray) {
			if (!(appiumMethod.elementIsDisplayed(element))) {
				errors.add(element);
			}
		}
		if (check) {
			appiumMethod.clickElement("//android.widget.CheckedTextView[@text='Choose an option']");
		}
		// if (goToDasboard)
		// check_screen();
		if (!errors.isEmpty()) {
			throw new AssertionError("Following elements not found: " + errors.toString());
		}
	}

	private void elementArrayClick() throws InterruptedException {
		for (String element : elementArray) {
			appiumMethod.clickElement(element);
		}
		if (successElementArray.length != 0) {
			Boolean errorNotPresent = false;
			String error = "\nExpected: " + successElementArray[1] + "\nActual: "
					+ appiumMethod.getText(successElementArray[0]);
			if (appiumMethod.getText(successElementArray[0]).contains(successElementArray[1]))
				errorNotPresent = true;
			if (goToDasboard)
				check_screen();
			Assert.assertTrue(errorNotPresent, error);
		}
		if (goToDasboard)
			check_screen();
	}

	@Then("([^\"]*) must be displayed")
	public void correct_message(String element) throws InterruptedException {
		appiumMethod.sleep(2000);
		if (element.contains("Error")) {
			appiumMethod.clickElement("//*[@text='OK']");
		} else if (element.contains("Correct")) {
			appiumMethod.clickBack();
		} else {
			appiumMethod.clickElement("//*[@text='OK']");
			check_screen();
			// appiumMethod.clickElement("toolbar_home_icon");
			// check_screen();
			// checkAndAllow();

		}
	}

	@When("^User selects inventory tab$")
	public void user_selects_inventory_tab() throws InterruptedException {
		appiumMethod.clickElement("//*[@text='Inventory']");
	}

	@Then("^User clicks on dropdowns and selects options in the dropdown$")
	public void select_dropdowns() throws InterruptedException {
		System.out.println("On Welcome screen");
		String[] str = new String[] { "Vietnam", "French", "Brazil Eastern Time(GMT-3:00)" };
		appiumMethod.findElement("welcome");
		/// appiumMethod.sleep(500);
		for (int i = 1; i < 4; i++) {
			appiumMethod.clickElement(Strings.dropdowns(i));
			appiumMethod.scrollToElementByTextContains( str[i - 1]);
			appiumMethod.clickElement("//*[@text='" + str[i - 1] + "']");

			/*String[] str = new String[] { "Albania", "French", "Pacific Standard Time(GMT-8:00)" };
			appiumMethod.clickElement(Strings.dropdowns(i));
			appiumMethod.sleep(1500);
			appiumMethod.clickElement("//*[@text='" + str[i - 1] + "']");*/
		}

		appiumMethod.clickElement("proceed_to_login");
	}

	@When("^User clicks on link to the reset my password$")
	public void click_forgot_password_link() {
		appiumMethod.clickElement("forgot_password");
		appiumMethod.clickElement("//android.widget.Button[@text='YES']");
	}

	@Then("^fedex page should be shown$")
	public void fedex_page_shown() throws InterruptedException {
		System.out.println("On the fedex page");
		appiumMethod.sleep(9000);
		String url = "https://www.fedex.com";
		if (url != null) {
			appiumMethod.clickBack();
		}
	}

	@Given("^User is on login page$")
	public boolean Login_page() {
		appiumMethod.findElement("loginTitle");
		System.out.println("User is on login page");
		return true;
	}

	@Then("dialpad sholuld be shown")
	public void dail_pad() throws InterruptedException {
		System.out.println("User is on dialpad");
		for (int i = 0; i < 3; i++) {
			appiumMethod.sleep(1000);
			appiumMethod.clickBack();
		}
	}

	@Then("^Welcome screen should be shown$")
	public void Welcome_screen() throws InterruptedException {
		if (appiumMethod.findElement("welcome")) {
			System.out.println("user is on welcome screen");
		}
		select_dropdowns();
	}

	@When("user is on ([^\"]*) screen")
	public void welcome_screen(String element) throws InterruptedException {
		while (!(appiumMethod.elementIsDisplayed(element))) {
			appiumMethod.sleep(1500);
			continue;
		}
	}

	@Then("strings should be present")
	public void check_string_availability() throws InterruptedException {
		if (appiumMethod.elementIsDisplayed("welcome")) {
			appiumMethod.sleep(3000);
			String actual = appiumMethod.getText("welcome_description");
			Assert.assertEquals(actual, Strings.expected);
			appiumMethod.sleep(3000);
		} else if (appiumMethod.elementIsDisplayed("loginTitle")) {
			HashMap<Integer, String> hash_map = new HashMap<Integer, String>();
			hash_map.put(1, "Please enter the required user credentials to continue.");
			hash_map.put(2, "Difficulty logging in? Click here to reset your password");
			hash_map.put(3, "Need Support? Phone 03456 070 809 or email uk@fedex.com");
			hash_map.put(4, "Are you a new user? Click here to register");
			hash_map.put(5, "Need to change location & language? Click here to reset your settings.");
			String[] actualStrings = new String[] { "login_description", "forgot_password", "need_support", "register",
			"reset_app_setting" };
			for (int i = 0; i < 5; i++) {
				appiumMethod.sleep(2000);
				String actual = appiumMethod.getText(actualStrings[i]);
				String expected = hash_map.get(i + 1);
				appiumMethod.sleep(2000);
				Assert.assertEquals(actual, expected);
			}
		} else if (appiumMethod.elementIsDisplayed("store_administration_title")) {
			check = false;
			elementArray = new String[] { "store_id", "store_address", "store_address_value" };
			elementArrayCheck();
			appiumMethod.sleep(3000);
			Assert.assertEquals(appiumMethod.getText("opening_hours"), Strings.opening_hours);
			appiumMethod.sleep(3000);
		} else if (appiumMethod.elementIsDisplayed("package_refusal")) {
			check = false;
			elementArray = new String[] { "trackingNum", "recipientDetails", "name", "address", "telephone",
					"confirm_refusal", "back" };
			elementArrayCheck();
			appiumMethod.sleep(3000);
			// String actual=appiumMethod.getText("refusal_success_message");
			Assert.assertEquals(appiumMethod.getText("refusal_success_message"), Strings.refusal_success_msg);
		} else {
			appiumMethod.clickElement("//*[@text='OK']");
		}

	}

	@Then("Scroll down to end of the page")
	public void scroll_down() throws InterruptedException, AWTException {

		//AppiumMethods.scrollToElement(AppiumMethods.driver, "Accept and Continue", true);

		appiumMethod.scrollToElementByTextContains("ENTIRE AGREEMENT");
		appiumMethod.clickElement("Accept and Continue");
		appiumMethod.clickElement("next_button");

		// appiumMethod.sleep(1000);
		//appiumMethod.scrollToExact("Accept and Continue");
		// appiumMethod.scrollToEnd(12);
		// appiumMethod.scrollAndClick("Accept and Continue");
		// do
		// {
		// appiumMethod.swiptToBottom();
		// appiumMethod.sleep(1000);
		// }while(!(appiumMethod.elementIsDisplayed("checkbox_terms_and_cond")));
		// appiumMethod.clickElement("checkbox_terms_and_cond");
		// appiumMethod.clickElement("next_button");
		// appiumMethod.sleep(1000);
		// ((Object) appiumMethod.driver).scrollTo("Register");
	}

	@When("User is on Refuse Package page")
	public void refuge_package_page() throws InterruptedException {
		while (!(appiumMethod.elementIsDisplayed("package_refusal"))) {
			appiumMethod.sleep(1000);
			continue;
		}
	}
	// if(appiumMethod.elementIsDisplayed("package_refusal"))
	// {
	// appiumMethod.sleep(1000);
	// }
	// }

	@Then("Refusal Reason dropdown with options should be present")
	public void drop_down_check() throws InterruptedException {
		appiumMethod.clickElement("refusal_reason_layout");
		// appiumMethod.clickElement("//*[@text='Refusal Reason']");
		appiumMethod.sleep(200);
		appiumMethod.swiptToBottom();
		appiumMethod.clickElement("//*[@text='Other']");
		click_confirm_refusal();
	}

	@When("User selects time from the timepicker")
	public void select_time() throws Exception {
		appiumMethod.findElement("store_administration_title");
		appiumMethod.sleep(1000);
		appiumMethod.swiptToBottom();
		for (int i = 1; i <= 7; i++) {
			for (int j = 1; j <= 4; j++) {
				appiumMethod.sleep(50);
				AppiumMethods.driver.findElementByXPath(Strings.days_XPath(i, j)).click();
				if (j == 1 || j == 3) {
					appiumMethod.clickElement("//*[@content-desc='1']");
					appiumMethod.clickElement("//*[@content-desc='10']");
					appiumMethod.clickElement("//*[@text='OK']");
				} else if (j == 2) {
					appiumMethod.clickElement("//*[@content-desc='Switch to text input mode for the time input.']");
					AppiumMethods.driver.findElementByXPath(Strings.time_picker(1)).clear();
					AppiumMethods.driver.findElementByXPath(Strings.time_picker(1)).sendKeys("02");
					AppiumMethods.driver.findElementByXPath(Strings.time_picker(2)).clear();
					AppiumMethods.driver.findElementByXPath(Strings.time_picker(2)).sendKeys("54");
					appiumMethod.clickElement("//*[@text='OK']");
				} else {
					appiumMethod.clickElement("//*[@content-desc='20']");
					appiumMethod.clickElement("//*[@content-desc='30']");
					appiumMethod.clickElement("//*[@text='OK']");
				}

			}
		}
	}

	@Then("Time should be shown on the respective textfield")
	public void time_display() {
		System.out.println("Time is displayed");
	}

	@Given("User is on the adminstration")
	public void on_admin_screen() {
		appiumMethod.clickElement("//*[@text='Administration']");
		appiumMethod.findElement("store_administration_title");
	}

	@When("User Sends value in the ([^\"]*) as ([^\"]*)")
	public void verfication_of_editfields(String element, String value) throws InterruptedException {

		appiumMethod.sendKeysToElement(element, value);
	}

	@Then("valditions for the textfields should be verified")
	public void textfield_validation() {
		System.out.println("Validated");

	}

	@And("Select the show list view instead button")
	public void select_list_view() throws InterruptedException {
		appiumMethod.clickElement("tv_filter_results");
		appiumMethod.sleep(1000);
		appiumMethod.clickElement("fourth_switch_view");
	}

	@And("user clicks on confirm refusal button")
	public void click_confirm_refusal() throws InterruptedException {
		appiumMethod.sleep(1500);
		// touchAction.tap(PointOption.point(749, 2419)).perform();
		appiumMethod.clickElement("confirm_refusal");
	}

	@Then("List of retail points to be displayed")
	public void retail_points() throws InterruptedException {
		check = false;
		elementArray = new String[] { "title", "distance", "address" };
		elementArrayCheck();
	}

	@When("User clicks on any of the retail point from the list")
	public void click_on_retail_point() {
		appiumMethod.clickElement(Strings.RETAIL_POINT);
	}

	@Then("Retail point details window to be displayed")
	public void retail_point_details_window() throws InterruptedException {
		check = false;
		elementArray = new String[] { "title", "address", "hours_of_operation", "day", "time", "infornation",
		"infornation_details" };
		elementArrayCheck();
		String str = appiumMethod.getText("infornation_details");
		Boolean result = str.equals(Strings.info_details);
		System.out.println(result);
	}

	@And("User enters address in the address field")
	public void input_address() throws InterruptedException {
		appiumMethod.sleep(2000);
		appiumMethod.sendKeysToElement("address", "UK");
		appiumMethod.sleep(5000);
	}

	@When("User clicks on the ([^\"]*) button")
	public void click_button(String btn_element) throws InterruptedException {
		appiumMethod.clickElement("//*[@text='" + btn_element + "']");
		appiumMethod.sleep(1000);
		appiumMethod.clickElement("//android.widget.Button[@text='YES']");

	}

	@Then("maps should be shown")
	public void map() throws InterruptedException {
		System.out.println("Directions is displayed on map");
		do {
			appiumMethod.clickBack();
			appiumMethod.sleep(4000);
		} while (!(appiumMethod.elementIsDisplayed("retail_locations")));

		// for(int i=0;i<2;i++)
		// {
		// appiumMethod.sleep(3000);
		// appiumMethod.clickBack();
		// }
	}

	@And("clicks on the ([^\"]*) button")
	public void click_delete(String element) {
		if (element.contains("delete"))
			appiumMethod.clickElement(Strings.DELETE_MESSAGE);
		// appiumMethod.clickElement("delete");
		// touchAction.tap(PointOption.point(808, 625)).perform();
		else
			// touchAction.tap(PointOption.point(808, 625)).perform();
			appiumMethod.clickElement("delete");
		appiumMethod.yes_confirm();
		// appiumMethod.clickElement("//android.widget.Button[@text='YES']");
		// else
		// appiumMethod.clickElement(element);
	}

	@And("Clicks on ([^\"]*)")
	public void click_labelled(String element) throws InterruptedException {
		appiumMethod.clickElement("//*[@text='" + element + "']");
		checkAndAllow();
	}

	@And("Selects address from the auto populated address")
	public void select_address() throws InterruptedException {
		appiumMethod.sleep(1000);
		touchAction.tap(PointOption.point(321, 559)).perform();
	}

	@And("User selects ([^\"]*) from dropdown")
	public void select_date(String element) throws InterruptedException {
		appiumMethod.clickElement("//*[@text='" + element + "']");
		appiumMethod.sleep(3000);
		appiumMethod.clickElement("//*[@text='OK']");
	}

	@And("clicks on ([^\"]*) button")
	public void click_buttons(String element) throws InterruptedException {
		appiumMethod.sleep(2000);
		appiumMethod.clickElement("//*[@text='" + element + "']");
	}

}
